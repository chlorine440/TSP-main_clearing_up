#ifndef _tsp_isr_h_
#define _tsp_isr_h_

#include "tsp_common_headfile.h"

void delay_1ms(uint32_t count);
uint32_t get_systick_counter(void);

#endif
