#ifndef _TSP_MENU_H
#define _TSP_MENU_H

#include "tsp_common_headfile.h"

uint8_t tsp_menu_loop(void);
void show_menu_cursor(uint8_t ItemNumber, uint16_t color);

void para_set(void); //参数设置


#endif