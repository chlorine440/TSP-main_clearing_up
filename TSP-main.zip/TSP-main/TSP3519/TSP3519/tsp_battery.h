#ifndef TSP_BATTERY_H
#define TSP_BATTERY_H

float tsp_battery_voltage(void);

#endif // TSP_BATTERY_H
